$(function(){

	$('.feedbacks__slider').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  prevArrow: ' <button class="slick-btn slick-prev"><img src="images/arrow_left.svg" alt="prev"></button>',
  nextArrow: ' <button class="slick-btn slick-next"><img src="images/arrow_right.svg" alt="next"></button>',

});


});